# Discord IP Grabber
Grabs a targets IP address and sends it along with its information through a discord webhook.

## Information
Once a target runs this program it will send the targets IP, Country, City ect through a discord webhook

## Previews
![](https://i.imgur.com/mBm1wyU.png)

## Usage
Run this command in CMD, terminal or PowerShell (if you don't already have the following modules installed):
```
pip install requests
pip install dhooks
pip install json
pip install datetime
```
1. Create a discord webhook.
2. Replace "webhook-url-here" with your webhooks url, make sure its discord.com instead of discordapp.com.
3. (Optional) Compile the file into a exe, dont know how? https://www.youtube.com/watch?v=UZX5kH72Yx4.
4. Done.

## Legal Notice
This is illegal if you use this without the consent of the owners (in this case, the Discord team). I am not accountable for anything you get into. This is 100% educational, please do not misuse this tool.
